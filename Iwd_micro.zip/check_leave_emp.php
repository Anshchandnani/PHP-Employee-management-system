<?php
	session_start();

	if (!isset($_SESSION['emp_id'])) {
		echo "Invalid Access. Please login first.";
		header('refresh:4; url=login.php');
		exit();
	}

	include 'db_connection.php';

	$emp_id = intval($_SESSION['emp_id']);

	$search_date = '';
	$query = "SELECT * FROM leave_info WHERE emp_id = $emp_id";

	if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search_date'])) {
		$search_date = trim($_POST['search_date']);
		if (!empty($search_date)) {
			$search_date = mysqli_real_escape_string($conn, $search_date);
			$query = "SELECT * FROM leave_info WHERE emp_id = $emp_id AND (from_date = '$search_date' OR to_date = '$search_date')";
		}
	}

	$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Leave Records</title>
    <style>
        body { font-family: Arial; background: #f0f0f0; padding: 20px; }
        table { border-collapse: collapse; width: 100%; background: #fff; }
        form { text-align: right; margin-bottom: 20px; }
        input[type=date], input[type=submit] { padding: 10px; margin: 10px; }
        th, td { padding: 10px; border: 1px solid #ccc; }
        th { background: #35424a; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        a { color: #35424a; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>

<h2>My Leave Records</h2>

<form method="POST">
    <label for="search_date">Search by Date:</label>
    <input type="date" name="search_date" value="<?php echo $search_date; ?>">
    <input type="submit" value="Search">
</form>

<table>
    <tr>
        <th>Leave Description</th>
        <th>From Date</th>
        <th>To Date</th>
        <th>Status</th>
    </tr>
    <?php
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['leave_desc'] . "</td>";
            echo "<td>" . $row['from_date'] . "</td>";
            echo "<td>" . $row['to_date'] . "</td>";
            echo "<td>";
			if ($row['status'] == 0) {
				echo "Waiting";
			} elseif ($row['status'] == 1) {
				echo "<span style='color:green; font-weight:bold;'>Approved</span>";
			} else {
				echo "<span style='color:red; font-weight:bold;'>Rejected</span>";
			}
			echo "</td></tr>";
        }
    } else {
        echo "<tr><td colspan='6'>No leave records found.</td></tr>";
    }
    ?>
</table>

<br><h3><a href="employee_home.php"><u>← Go Back</u></a></h3>

</body>
</html>
