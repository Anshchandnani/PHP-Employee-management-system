<?php
	session_start();
	if(!isset($_SESSION['user_name']) || $_SESSION['user_name'] != 'employee') {
		echo "Invalid Access";
		header('refresh: 4; url=login.php');
		echo 'You will be redirected to Login page in 4 seconds';
		exit();
	}

	include 'db_connection.php';
	$e_id = $_SESSION['emp_id'];
	$result = $conn->query("SELECT * FROM attendance_info WHERE emp_id=$e_id");
?>

<html>
<head>
	<title>Employee Information Table</title>
	<style>
		body{font-family:Arial,sans-serif;background-color:#f0f0f0;padding:20px}
		table{border-collapse:collapse;width:100%;background-color:#fff}
		th,td{padding:10px;text-align:left;border:1px solid #ccc}
		th{background-color:#35424a;color:#fff}
		tr:nth-child(even){background-color:#f9f9f9}
		a{color:#35424a;text-decoration:none;font-weight:bold}
	</style>
</head>
<body>

	<h2>Employee Attendance</h2>

	<table>
		<tr>
			<th>Employee Id</th>
			<th>Date</th>
			<th>Status</th>
		</tr>
		<?php
			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					echo "<tr>";
					echo "<td>".$row['emp_id']."</td>";
					echo "<td>".$row['date']."</td>";
					echo "<td>".$row['status']."</td>";
					echo "</tr>";
				}
			} else {
				echo "<tr><td colspan='6'>No records found</td></tr>";
			}
			$conn->close();
		?>
	</table>
	<br>
	<a href="employee_home.php">← Go Back</a>
</body>
</html>
