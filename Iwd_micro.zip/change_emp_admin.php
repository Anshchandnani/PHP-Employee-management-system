<?php
	session_start();
	if (!isset($_SESSION['user_name']) || $_SESSION['user_name'] != 'admin') {
		echo "Invalid Access";
		header('refresh:2; url=login.php');
		exit();
	}

	include 'db_connection.php';
	if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['emp_id']) && isset($_POST['change_status'])) {
		$emp_id = $_POST['emp_id'];
		$new_status = $_POST['change_status']; // 0 or 1
		$update_query = "UPDATE emp_info SET status = '$new_status' WHERE emp_id = $emp_id";
		$conn->query($update_query);
	}

	$result = $conn->query("SELECT * FROM emp_info");
?>

<html>
<head>
    <title>Leave Employee Management</title>
    <style>
        body {font-family: Arial, sans-serif;background: #f0f0f0;padding: 20px;}
        table {border-collapse: collapse;width: 100%;background: #fff;}
        th, td {padding: 10px;border: 1px solid #ccc;}
        th {background: #35424a;color: white;}
        tr:nth-child(even) {background-color: #f9f9f9;}
        a {color: #35424a;text-decoration: none;font-weight: bold;}
        .btn {padding: 5px 10px;border: none;color: white;font-weight: bold;cursor: pointer;}
        .on-leave {background-color: red;}
        .hired {background-color: green;}
    </style>
</head>
<body>
    <h2>Employee Status Management</h2>

    <table>
        <tr>
            <th>Employee ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php
		if ($result && $result->num_rows > 0) {
		while ($row = $result->fetch_assoc()) {
			$emp_id = $row['emp_id'];
			$name = $row['name'];
			$email = $row['email'];
			$phone = $row['phone'];
			$status = $row['status'];
			$status_text = ($status == 0) ? 'On Leave' : 'Hired';
			$bg_color = ($status == 0) ? 'red' : 'green';
			$change_status = ($status == 0) ? 1 : 0;
			$btn_class = ($status == 0) ? 'hired' : 'on-leave';
			$btn_label = ($status == 0) ? 'Back' : 'Off Duty';

			echo "<tr>";
			echo "<td>$emp_id</td>";
			echo "<td>$name</td>";
			echo "<td>$email</td>";
			echo "<td>$phone</td>";
			echo "<td style='color: white; font-weight: bold; background-color: $bg_color;'>$status_text</td>";
			echo "<td>
					<form method='post' style='display:inline-block;'>
						<input type='hidden' name='emp_id' value='$emp_id'>
						<input type='hidden' name='change_status' value='$change_status'>
						<input type='submit' class='btn $btn_class' value='$btn_label'>
					</form>
				  </td>";
			echo "</tr>";
		}
	} else {
		echo "<tr><td colspan='6'>No employees found.</td></tr>";
	}
	?>
    </table>

    <br><h3><a href="admin_home.php"><u>← Go Back</u></a></h3>
</body>
</html>
