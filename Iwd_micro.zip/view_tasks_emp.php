<?php
	session_start();
	if (!isset($_SESSION['user_name']) || $_SESSION['user_name'] != 'employee') {
		echo "Invalid Access";
		header('refresh: 2; url=login.php');
		echo 'You will be redirected to Login page in 2 seconds';
		exit();
	}

	include 'db_connection.php';
	$e_id = $_SESSION['emp_id'];

	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['mark_completed'])) {
		$task_id = intval($_POST['task_id']);
		$conn->query("UPDATE task_info SET status='1' WHERE task_id=$task_id AND emp_id=$e_id");
	}
 
	$search = '';
	$search_sql = "SELECT * FROM task_info WHERE emp_id=$e_id";
	if (isset($_POST['search'])) {
		$search = trim($_POST['search']);
		$search_sql .= " AND (task_desc LIKE '%$search%' OR assign_date LIKE '%$search%' OR due_date LIKE '%$search%')";
	}

	$result = $conn->query($search_sql);
?>

<html>
<head>
    <title>Your Tasks Information Table</title>
    <style>
        body { font-family: Arial; background-color: #f0f0f0; padding: 20px; }
        table { border-collapse: collapse; width: 100%; background-color: #fff; }
        th, td { padding: 10px; border: 1px solid #ccc; }
        th { background-color: #35424a; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        a { color: #35424a; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>
	<h2>Employee Task Information</h2>

	<form method="post">
		<input type="text" name="search" placeholder="Search by Task, Assign Date, Due Date" value="<?php echo $search; ?>">
		<input type="submit" value="Search">
	</form>

	<table>
		<tr>
			<th>Task Description</th>
			<th>Assign Date</th>
			<th>Due Date</th>
			<th>Status</th>
			<th>Action</th>
		</tr>
		<?php
		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
				echo "<tr>";
				echo "<td>{$row['task_desc']}</td>";
				echo "<td>{$row['assign_date']}</td>";
				echo "<td>{$row['due_date']}</td>";
				echo "<td>" . ($row['status'] == 1 ? "Completed" : "Pending") . "</td>";
				echo "<td>";
				if ($row['status'] == 0) {
					echo "<form method='post' style='display:inline;'>
							<input type='hidden' name='task_id' value='{$row['task_id']}'>
							<input type='submit' name='mark_completed' value='Mark as Completed'>
						  </form>";
				} else {
					echo "✔ Done";
				}
				echo "</td></tr>";
			}
		} else {
			echo "<tr><td colspan='6'>No records found</td></tr>";
		}
		$conn->close();
		?>
	</table>

	<br><a href="employee_home.php"><u>← Go Back</u></a>
</body>
</html>
