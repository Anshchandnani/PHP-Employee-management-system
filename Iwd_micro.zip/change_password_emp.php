<?php
	session_start();
	if (!isset($_SESSION['user_name']) || $_SESSION['user_name'] != 'employee') {
		echo "Invalid Access";
		header('refresh: 2; url=login.php');
		exit();
	}

	include 'db_connection.php';

	$emp_id = $_SESSION['emp_id'];
	$message = '';
	$error = '';

	function is_alphanumeric($str) {
		return preg_match("/^[A-Za-z0-9@]+$/", $str);
	}

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$current_password = trim($_POST['current_password']);
		$new_password     = trim($_POST['new_password']);
		$confirm_password = trim($_POST['confirm_password']);

		if (strlen($current_password) < 6 || strlen($new_password) < 6 || strlen($confirm_password) < 6) {
			$error = "All passwords must be at least 6 characters long.";
		} elseif (!$current_password || !$new_password || !$confirm_password) {
			$error = "All fields are required.";
		} elseif (!is_alphanumeric($current_password) || !is_alphanumeric($new_password) || !is_alphanumeric($confirm_password)) {
			$error = "Passwords must contain only letters and numbers.";
		} elseif ($new_password !== $confirm_password) {
			$error = "New Password and Confirm Password do not match!";
		} else {
			$query = "SELECT * FROM emp_info WHERE emp_id = $emp_id";
			$result = $conn->query($query);
			$row = $result->fetch_assoc();

			if ($row && password_verify($current_password, $row['password'])) {
				$hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
				$update = "UPDATE emp_info SET password = '$hashed_new_password' WHERE emp_id = $emp_id";

				if ($conn->query($update)) {
				$email_query = "SELECT email FROM emp_info WHERE emp_id = $emp_id";
				$email_result = $conn->query($email_query);
				$email_row = $email_result->fetch_assoc();

				if ($email_row && !empty($email_row['email'])) {
					$to = $email_row['email'];
					$subject = "Password Changed Notification";
					$message_body = "Hello,\n\nThis is to notify you that your password has been successfully changed.\nIf you did not perform this action, please contact support immediately.\n\nRegards,\nEmployee Management System";
					$headers = "From: noreply@yourdomain.com";

					// send the email
					mail($to, $subject, $message_body, $headers);
				}

				$message = "Password changed successfully!";
				echo "<script>alert('$message');</script>";
			} else {
					$error = "Failed to update password. Please try again.";
					echo "<script>alert('$error');</script>";
				}
			} else {
				$error = "Current password is incorrect!";
				echo "<script>alert('$error');</script>";
			}
		}
	}
?>

<html>
<head>
    <title>Change Password</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f2f2f2; padding: 30px; }
        form { max-width: 400px; margin: auto; background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #333; }
        input[type="password"], input[type="submit"] {width: 97%; padding: 10px; margin: 10px 0; border-radius: 5px; border: 1px solid #ccc;}
        input[type="submit"] {width: 102%;background-color: #35424a; color: white; font-weight: bold; cursor: pointer;}
        input[type="submit"]:hover {background-color: #222;}
        .message1 { text-align: center; color: red; margin-top: 10px; }
		.message2 { text-align: center; color: green; margin-top: 10px; }
        a { display: block; text-align: center; margin-top: 15px; text-decoration: none; color: #35424a; font-weight: bold; }
    </style>
    <script>
        function validateForm() {
            const currPass = document.getElementById("current_password").value.trim();
            const newPass = document.getElementById("new_password").value.trim();
            const confPass = document.getElementById("confirm_password").value.trim();
            let errors = [];

            if (currPass === "" || newPass === "" || confPass === "") {
                errors.push("All fields are required.");
            }
            if (currPass.length < 6 || newPass.length < 6 || confPass.length < 6) {
                errors.push("All passwords must be at least 6 characters long.");
            }
            const alphanumRegex = /^[A-Za-z0-9@]+$/;
            if (!alphanumRegex.test(currPass) || !alphanumRegex.test(newPass) || !alphanumRegex.test(confPass)) {
                errors.push("Passwords must contain only letters and numbers.");
            }
            if (newPass !== confPass) {
                errors.push("New Password and Confirm Password do not match!");
            }

            if (errors.length > 0) {
                alert(errors.join("\n"));
                return false;
            }
            return true;
        }
    </script>
</head>
<body>

    <form method="POST" onsubmit="return validateForm()">
        <h2>Change Password</h2>
        <label>Current Password:</label>
        <input type="password" id="current_password" name="current_password" required minlength="6" pattern="[A-Za-z0-9@]+" title="Only letters and numbers allowed.">

        <label>New Password:</label>
        <input type="password" id="new_password" name="new_password" required minlength="6" pattern="[A-Za-z0-9@]+" title="Only letters and numbers allowed.">

        <label>Confirm New Password:</label>
        <input type="password" id="confirm_password" name="confirm_password" required minlength="6" pattern="[A-Za-z0-9@]+" title="Only letters and numbers allowed.">

        <input type="submit" value="Change Password">
        
        <a href="employee_home.php"><u>← Go Back</u></a>
    </form>

</body>
</html>