<?php
	session_start();
	include 'db_connection.php';

	if (!isset($_SESSION['user_name']) || $_SESSION['user_name'] != 'admin') {
		echo "Invalid Access";
		header('refresh: 4; url=login.php');
		echo 'You will be redirected to Login page in 4 seconds';
		exit();
	}

	$search = '';
	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['search'])) {
		$search = trim($_POST['search']);
		$search_emp_id = intval($search);
	}
	
	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['approve_btn'])) {
		$leave_id = intval($_POST['leave_id']);
		$conn->query("UPDATE leave_info SET status = '1' WHERE leave_id = $leave_id");
		header("Location: manage_leaves_admin.php");
		exit();
	}

	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reject_btn'])) {
		$leave_id = intval($_POST['leave_id']);
		$conn->query("UPDATE leave_info SET status = '2' WHERE leave_id = $leave_id");
		header("Location: manage_leaves_admin.php");
		exit();
	}

	if (!empty($search)) {
		$query = "SELECT * FROM leave_info WHERE emp_id = $search_emp_id AND from_date >= CURDATE()";
	} else {
		$query = "SELECT * FROM leave_info WHERE from_date >= CURDATE()";
	}
	$result = $conn->query($query);
?>

<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Leave Requests</title>
    <style>
        body { font-family: Arial; background: #f0f0f0; padding: 20px; }
		h2 {color: #333;}
        form {margin-bottom: 20px;text-align: right;}
        input[type="text"] {padding: 8px;width: 250px; margin-right: 10px;}
        input[type="submit"] {padding: 8px 16px;background-color: #35424a;color: white;border: none; cursor: pointer;}
        input[type="submit"]:hover {background-color: #222;}
        table { border-collapse: collapse; width: 100%; background: #fff; }
        th, td { padding: 10px; border: 1px solid #ccc; }
        th { background: #35424a; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        input[type="submit"] { padding: 5px 10px; margin: 2px; }
    </style>
</head>
<body>
<h2>Manage Leave Requests</h2>
<form method="POST">
    <input type="text" name="search" placeholder="Search by Employee ID" value="<?php echo $search; ?>">
    <input type="submit" value="Search">
</form>
<br>
<table>
    <tr>
        <th>Employee ID</th>
        <th>Description</th>
        <th>From</th>
        <th>To</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    <?php
	if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['emp_id']}</td>";
        echo "<td>" . htmlspecialchars($row['leave_desc']) . "</td>";
        echo "<td>{$row['from_date']}</td>";
        echo "<td>{$row['to_date']}</td>";

        $status_text = ($row['status'] == 0) ? 'Waiting' : (($row['status'] == 1) ? 'Approved' : 'Rejected');
        echo "<td>$status_text</td>";

        echo "<td>";
        if ($row['status'] == 0) {
            echo "<form method='POST' style='display:inline;'>
                    <input type='hidden' name='leave_id' value='{$row['leave_id']}'>
                    <input type='submit' name='approve_btn' value='Approve'>
                  </form>
                  <form method='POST' style='display:inline;'>
                    <input type='hidden' name='leave_id' value='{$row['leave_id']}'>
                    <input type='submit' name='reject_btn' value='Reject'>
                  </form>";
        } else {
            echo "✔ Done";
        }
        echo "</td>";
        echo "</tr>";
		}
	} else {
		echo "<tr><td colspan='7'>No leave records found.</td></tr>";
	}
?>
</table>

<br><h3><a href="admin_home.php">← Go Back</a></h3>
</body>
</html>
